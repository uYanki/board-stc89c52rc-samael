#include "stc89c51.h"


int main(void)
{
    P1 = 0;

	while (1);
}

